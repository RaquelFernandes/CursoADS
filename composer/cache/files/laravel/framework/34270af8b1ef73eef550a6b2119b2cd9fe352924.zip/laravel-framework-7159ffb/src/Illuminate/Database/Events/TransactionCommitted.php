<?php

namespace Illuminate\Database\Events;

class TransactionCommitted extends ConnectionEvent
{
    //
}
